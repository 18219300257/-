package com.viewProduct;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewProductServlet")
public class ViewProductServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//获取id
		String id=req.getParameter("id");
		//System.out.println(id);
		HttpSession session = req.getSession();
		
		//创建Service对象
		ViewService view=new ViewService();
		List list=view.findById(id);
		
		//把list存入session
		session.setAttribute("viewProduct", list);
		
		//转发到商品信息详情页面
		RequestDispatcher rd=req.getRequestDispatcher("/viewProduct.jsp");
		rd.forward(req, resp);
	}
	
}
