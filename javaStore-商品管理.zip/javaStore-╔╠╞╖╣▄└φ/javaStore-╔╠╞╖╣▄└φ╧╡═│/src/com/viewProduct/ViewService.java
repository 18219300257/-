package com.viewProduct;

import java.util.ArrayList;
import java.util.List;

import com.model.ProductBean;
import com.product.ProductDaoImpl;

public class ViewService {
	public List findById(String id) {
		int id1 = Integer.parseInt(id);
		List list = new ArrayList();
		// 创建dao对象
		ProductDaoImpl dao = new ProductDaoImpl();
		list = dao.findProductById(id1);
		return list;
	}
	
	//测试
//	public static void main(String[] args) {
//		ViewService view=new ViewService();
//		List list=view.findById("37");
//		System.out.println(list);
//	}
}
