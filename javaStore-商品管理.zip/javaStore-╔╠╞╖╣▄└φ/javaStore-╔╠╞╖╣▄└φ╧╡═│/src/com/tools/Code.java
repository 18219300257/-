package com.tools;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/code")
public class Code extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//1.随机生成验证码
		
		//中文验证码
//		String[] range= {"零","壹","贰","叁"};
//		Random rdm=new Random(System.currentTimeMillis());
//		int idx=rdm.nextInt(range.length);
//		String code=range[idx];
		
		//算式验证码
		String[] range= {"+","-","*"};
		Random rdm=new Random(System.currentTimeMillis());
		int idx=rdm.nextInt(range.length);
		int a=rdm.nextInt(10),b=rdm.nextInt(10);
		String code=a+range[idx]+b+"=";
		int result=0;
		switch(idx) {
		case 0:result=a+b;break;case 1:result=a-b;break;
		case 2:result=a*b;
			}
		
		//数字验证码
//		Random rdm=new Random(System.currentTimeMillis());
//		String code=rdm.nextInt(10)+"";//nextInt(10) [0.9]
		
		
		HttpSession session=req.getSession();
//		session.setAttribute("trueAnswer", code);//利用会话保存验证码的答案
		session.setAttribute("trueAnswer", result+"");//利用会话保存验证码的答案
		//2.验证码转成图片
		int w=250,h=150;
		BufferedImage img=new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g=img.createGraphics();
		Color bgColor=new Color(0xdcdcdc);
		g.setColor(bgColor);
		g.fillRect(0, 0, w, h);
		g.setColor(Color.RED);
		Font font=new Font(null,Font.BOLD,80);
		g.setFont(font);
		g.drawString(code, w/6, h/2);
		//3.增加干扰
		g.setColor(Color.blue);
		for(int line=1;line<=3;line++) {
			int[] x=new int[4];
			int[] y=new int[4];
			for(int p=0;p<4;p++) {
				x[p]=rdm.nextInt(w);
				y[p]=rdm.nextInt(h);
			}
			g.drawPolyline(x, y, x.length);
			
		}
		//4.把图片发送给客户端
		resp.setContentType("image/jpeg");
		ImageIO.write(img,"jpg",resp.getOutputStream());
	}
	
}
