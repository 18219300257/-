package com.tools;

import java.sql.ResultSet;
import java.sql.Statement;

public class Total extends MyDB {
	// 统计商品表里面的总条目数
	public int counTotal() {
		int total=0;
		try {
			// 获取连接
			getConn();
			String sql = "select count(*) from goods";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				total = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return total;
	}
	
	//测试
//	public static void main(String[] args) {
//		Total dao=new Total();
//		int a=dao.counTotal();
//		System.out.println("goods表一共有:"+a+"条数据！");
//	}
}


