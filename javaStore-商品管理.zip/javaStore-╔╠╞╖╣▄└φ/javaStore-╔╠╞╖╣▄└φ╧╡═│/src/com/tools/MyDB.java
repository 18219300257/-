package com.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDB{
	public static Connection conn = null;
	// 提供获得数据库连接对象
	public static void getConn() {
		String driver = "com.mysql.jdbc.Driver";
//		String url="jdbc:sqlserver://192.168.59.1:1433;DatabaseName=test";
		String url = "jdbc:mysql://localhost:3306/test";
		String username = "root";
		String password = "123456";
		try {
			// 1、加载驱动
			Class.forName(driver);
//			System.out.println("驱动加载成功");
			// 2、连接数据库
			conn = DriverManager.getConnection(url, username, password);
//			System.out.println("数据库连接成功");
//			System.out.println(conn);

		} catch (ClassNotFoundException e) {
			System.out.println("驱动加载出错.....");
		} catch (SQLException e) {
			System.out.println("数据库连接出错......");
		}

	}

}
