package com.tools;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class MyRequest extends HttpServletRequestWrapper {
	private HttpServletRequest request;

	public MyRequest(HttpServletRequest request) {
		super(request);
		this.request = request;
	}

	public String getParameter(String name) {
		String value = this.request.getParameter(name);

		if (value == null) {
			return null;
		}

		// 如果不是get方法的，直接返回就行了
		if (!this.request.getMethod().equalsIgnoreCase("get")) {
			return null;
		}

		try {

			// 进来了就说明是get方法，把乱码的数据
			value = new String(value.getBytes("UTF-8"), this.request.getCharacterEncoding());
			return value;

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();

			throw new RuntimeException("不支持该编码");
		}

	}

}
