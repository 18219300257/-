package com.shoppingCart;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UpdateQuantityServlet")
public class UpdateQuantityServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 获取得到用户想要修改哪一本书的id和相对应的数量
		String id = req.getParameter("id");
		String quantity = req.getParameter("quantity");
		HttpSession session=req.getSession();
		
		int id1=Integer.parseInt(id);
		//获取当前用户的购物车
		Cart cart = (Cart) session.getAttribute("cart");
		//System.out.println("商品的id:"+id);
		boolean a;
		//调用CartDapImpl的修改方法
		CartDaoImpl cartDaoImpl=new CartDaoImpl();
		a=cartDaoImpl.updateQuantity(id1, cart, quantity);
		
		if(a==true) {
			//修改完就重定向到购物车页面
			resp.sendRedirect(req.getContextPath()+"/listCart.jsp");
		}else {
			System.out.println("修改出错");
		}
		
	}

}
