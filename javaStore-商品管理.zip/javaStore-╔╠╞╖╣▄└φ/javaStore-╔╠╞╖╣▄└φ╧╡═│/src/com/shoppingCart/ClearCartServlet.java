package com.shoppingCart;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ClearCartServlet")
public class ClearCartServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 得到用户相对应的购物车
		Cart cart = (Cart) req.getSession().getAttribute("cart");
		boolean a;
		// 调用方法
		CartDaoImpl cartDaoImpl = new CartDaoImpl();
		a = cartDaoImpl.clearCart(cart);
		if (a == true) {
			// 跳转到购物车界面
			resp.sendRedirect(req.getContextPath() + "/listCart.jsp");
		} else {
			System.out.println("清空失败！");
		}
	}

}
