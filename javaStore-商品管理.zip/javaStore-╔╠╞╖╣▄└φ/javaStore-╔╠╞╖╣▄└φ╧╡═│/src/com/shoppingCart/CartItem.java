package com.shoppingCart;

/**
 * 购物项实体:购物项代表的是当前的商品，并表示该商品出现了几次
 * 
 * @author AAA
 *
 */
public class CartItem {
	private Product product;
	private int quantity;// 商品的数量

	// 该购物项（商品--不一定只有一件）的价钱应该等于商品的数量*价格
	private double price;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	//商品的价钱*数量
	public double getPrice() {
		return product.getPrice()*this.quantity;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
