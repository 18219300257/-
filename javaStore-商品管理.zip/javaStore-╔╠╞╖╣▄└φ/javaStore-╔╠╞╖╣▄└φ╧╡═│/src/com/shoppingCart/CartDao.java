package com.shoppingCart;

import java.util.List;
import java.util.Map;





public interface CartDao {
	/**
	 * 根据id获取某样商品
	 * @param id 商品的id
	 * @param cart 购物车对象
	 * @return 
	 */
	public Map<Long, Product> findProduct(int id);
	
	
	/**
	 * 把用户想买的商品添加到当前用户的购物车上
	 * @param id 商品的id
	 * @param cart 购物车对象
	 * @return 返回值为布尔类型
	 */
	public boolean buyProudct(int id,Cart cart);
	
	/**
	 * 修改购物车商品数量的方法
	 * @param id 商品的id
	 * @param cart 当前用户的购物车
	 * @param quantity 商品的数量
	 * @return 返回值为布尔类型
	 */
	public boolean updateQuantity(int id, Cart cart, String quantity);
	
	
	/**
	 * 删除购物车里的某项商品
	 * @param id 商品的id
	 * @param cart 当前用户的购物车
	 * @return 返回值为布尔类型
	 */
	public boolean deleteProduct(int id, Cart cart);
	
	
	/**
	 * 
	 * @param cart 当前用户的购物车
	 * @return 返回值为布尔类型
	 */
	public boolean clearCart(Cart cart);
}
