package com.shoppingCart;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.model.ProductBean;
import com.product.ProductDaoImpl;

public class CartDaoImpl implements CartDao {
	/**
	 * 把用户想买的商品添加到当前用户的购物车上
	 * 
	 * @return
	 */
	@Override
	public Map<Long, Product> findProduct(int id) {

		// 1、创建一个Map集合用于存放商品信息
		Map<Long, Product> map = new LinkedHashMap<>();
		List<ProductBean> list = new ArrayList<ProductBean>();

		// 2、调用ProductDaoImpl的findProductById(int id1)方法查找商品
		ProductDaoImpl dao = new ProductDaoImpl();

		// 3、得到商品的List集合，把它转为Map集合
		list = dao.findProductById(id);

		for (int i = 0; i < list.size(); i++) {
			ProductBean pro = list.get(i);
			map.put(pro.getId(),
					new Product(pro.getId(), pro.getName(), Double.parseDouble(pro.getPrice()), pro.getPlace()));
		}

		return map;

	}

	// 测试
//	public static void main(String[] args) {
//		Map<Long, Product> map1 = new LinkedHashMap<>();
//		CartDaoImpl dao=new CartDaoImpl();
//		//商品的id为30
//		map1=dao.findProduct(30);
//		for(Entry<Long, Product> me : map1.entrySet()) {
//			System.out.println(me.getValue().getName());
//		}
//	}

	/**
	 * 把用户想买的商品添加到当前用户的购物车上
	 */
	public boolean buyProudct(int id, Cart cart) {
		Map<Long, Product> map = new LinkedHashMap<>();

		// 获取Map集合
		CartDaoImpl dao = new CartDaoImpl();
		map = dao.findProduct(id);
		for (Entry<Long, Product> me : map.entrySet()) {
			Product product = me.getValue();

			// 把从Map集合中获取到的Value值传给addProduct()
			cart.addProduct(product);

			// System.out.println(me.getValue());
		}

		// System.out.println(map);

		return true;
	}

	// 测试
//	public static void main(String[] args) {
//		boolean a;
//		boolean b;
//		Cart cart=new Cart();
//		CartDaoImpl dao=new CartDaoImpl();
//		a=dao.buyProudct(53, cart);
//		b=dao.buyProudct(53, cart);
//		System.out.println(a);
//	}

	/**
	 * 修改商品数量的方法
	 */
	@Override
	public boolean updateQuantity(int id, Cart cart, String quantity) {
		try {
			// 通过商品的id获取得到购物车的购物项，再修改购物项的数量即可！（因为商品的id和获取购物项的关键字是一致的！）
			Product product = new Product();
			System.out.println("商品的id:" + id);
			for (Entry<Long, CartItem> me : (cart.getProductMap()).entrySet()) {
				if (id == me.getKey()) {

					System.out.println("这是修改的商品的id:" + id);
					// 对数量进行修改
					me.getValue().setQuantity(Integer.parseInt(quantity));
					return true;
				}
//				System.out.println("购物车商品的id:"+me.getKey());
			}
//			System.out.println("购物车里的商品："+cart.getProductMap());
//			System.out.println("要修改的商品："+cart.getProductMap().get(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	/**
	 * 删除购物车里的某项商品
	 */
	@Override
	public boolean deleteProduct(int id, Cart cart) {
		for (Entry<Long, CartItem> me : (cart.getProductMap()).entrySet()) {
			if (id == me.getKey()) {
				// 对商品进行删除
				// cart.getProductMap():这是一个装有商品信息的Map集合
				cart.getProductMap().remove(me.getKey());
				return true;
			}
		}
		return false;
	}

	/**
	 * 清空购物车
	 */
	@Override
	public boolean clearCart(Cart cart) {
		cart.getProductMap().clear();
		return true;
	}

}
