package com.shoppingCart;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.UserBean;

@WebServlet("/JoinCartAndBuyServlet")
public class JoinCartAndBuyServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 获取session
		HttpSession session = req.getSession();
		// 获取用户登录的状态
		UserBean obj = (UserBean) session.getAttribute("loginedUser");
		// 判断用户是否有登录
		if (obj == null) {
			session.setAttribute("msg", "您还没有登录，请请先登录！");
			// 转发到login_1.jsp页面
			RequestDispatcher rd = req.getRequestDispatcher("/login_1.jsp");
			rd.forward(req, resp);
			return;
		} else {
			// 获取用户点击商品的id
			String id = req.getParameter("id");
			System.out.println("商品的id是：" + id);
			int id1 = Integer.parseInt(id);

			// 把用户想要买的书放到购物车上
			// 用户不单单只有一个，要让购物车上只为当前的用户服务，就需要用到会话跟踪技术了
			Cart cart = (Cart) session.getAttribute("cart");
			System.out.println(cart);
			// 如果当前用户还没有点击过购买的商品，那么是用户的购物车是空的
			if (cart == null) {
				System.out.println("用户没有点击过购买商品");
				cart = new Cart();
				// 把购物车存入session
				session.setAttribute("cart", cart);
				
				//持久化
				Cookie cookie=new Cookie("cart",session.getId());
				cookie.setMaxAge(200);
				resp.addCookie(cookie);
			}

			// 调用CartDaoImpl的方法，实现购买功能
			CartDaoImpl cartDaoImpl = new CartDaoImpl();
			boolean a;
			a = cartDaoImpl.buyProudct(id1, cart);
			if (a == true) {
				// 跳转到购物车界面
				resp.sendRedirect(req.getContextPath()+"/listCart.jsp");
				return;
			}

		}
	}

}
