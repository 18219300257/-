package com.shoppingCart;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DeleteCartProductServlet")
public class DeleteCartProductServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 获取得到用户想要删除哪个书本的id
		String id = req.getParameter("id");
		int id1 = Integer.parseInt(id);

		// 获取该用户相对应的购物车对象
		Cart cart = (Cart) req.getSession().getAttribute("cart");
		boolean a;
		// 调用方法删除购物车里的商品
		CartDaoImpl cartDaoImpl = new CartDaoImpl();
		a = cartDaoImpl.deleteProduct(id1, cart);
		if (a == true) {
			// 跳转到购物车界面
			resp.sendRedirect(req.getContextPath() + "/listCart.jsp");
		}else {
			System.out.println("删除失败");
		}
	}

}
