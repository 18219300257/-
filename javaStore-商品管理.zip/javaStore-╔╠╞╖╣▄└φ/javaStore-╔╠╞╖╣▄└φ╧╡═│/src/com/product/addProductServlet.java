package com.product;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/com.product/addProductServlet/addProduct")
public class addProductServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		
		//获取数据
		String name = req.getParameter("name");
		String price = req.getParameter("price");
		Float price1=Float.parseFloat(price);
		String place = req.getParameter("place");
		HttpSession session=req.getSession();
		//创建dao对象
		ProductDaoImpl dao=new ProductDaoImpl();
		boolean flag=dao.insert(name, price1, place);
		if(flag==true) {
			//重定向到查询所有的servlet
			resp.sendRedirect(req.getContextPath() + "/findProductPageList");
		}else {
			//给提示信息
			session.setAttribute("false_msg", "添加失败！");
			//重定向到本页面
			resp.sendRedirect(req.getContextPath() + "/addProduct.jsp");
		}
		
	}

}
