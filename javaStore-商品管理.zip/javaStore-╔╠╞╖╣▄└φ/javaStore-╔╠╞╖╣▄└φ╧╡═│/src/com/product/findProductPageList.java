package com.product;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.AdminBean;
import com.model.PageBean;
import com.model.ProductBean;
import com.model.UserBean;
import com.page.Pageservice;

@WebServlet("/findProductPageList")
public class findProductPageList extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		// 获取数据
		String p = req.getParameter("p");
		String m = req.getParameter("m");
		if (p == null)
			p = "1";
		if (m == null)
			m = "4";
		
		//获取查询条件集合
		Map<String,String[]> condition = req.getParameterMap();
		//System.out.println("findProductPageList里获取的condition:"+condition.get("name"));
		//创建PageService对象
		Pageservice pag = new Pageservice();
		//调用方法查询
		PageBean bean = pag.findProductByPage(p, m, condition);
		//获取分页集合
		List<ProductBean> list=bean.getList();
		HttpSession session=req.getSession();
		
		//获取登录的用户对象
		AdminBean username=(AdminBean)session.getAttribute("loginedAdmin");
		
		//保存上面获取的数据，发送到展示的页面
		session.setAttribute("PageBean", bean);
		session.setAttribute("list", list);
		session.setAttribute("condition", condition);//用于查询条件的回显
		session.setAttribute("loginedUser", username);
		RequestDispatcher rd = req.getRequestDispatcher("/main.jsp");
		rd.forward(req, resp);
		
		
		
		
		
		
		
		
		
	}

}
