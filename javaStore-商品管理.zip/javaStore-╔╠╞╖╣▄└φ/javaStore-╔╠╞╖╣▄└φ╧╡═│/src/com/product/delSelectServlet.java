package com.product;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/com.product/delSelectServlet/delSelect")
public class delSelectServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		
		//获取id集合
		String ids[] = req.getParameterValues("ids");
		
		//创建dao对象
		ProductDaoImpl dao=new ProductDaoImpl();
		dao.delSelectProduct(ids);
		
		//重定向到查询所有的servlet
		resp.sendRedirect(req.getContextPath() + "/findProductPageList");
	}

}
