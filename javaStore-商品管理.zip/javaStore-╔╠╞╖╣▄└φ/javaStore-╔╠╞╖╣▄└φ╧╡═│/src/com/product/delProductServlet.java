package com.product;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/delProductServlet")
public class delProductServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		//获取id
		String id = req.getParameter("id");
		int id1 = Integer.parseInt(id);
		
		//构建dao对象
		ProductDaoImpl dao=new ProductDaoImpl();
		dao.delProduct(id1);
		//重定向到findProductPageList
		resp.sendRedirect(req.getContextPath()+"/findProductPageList");
	}

}
