package com.product;

import java.util.List;
import java.util.Map;



public interface ProductDao  {
	/**
	 *  1、动态条件分页查询
	 * @param page 用户要看第几页
	 * @param max  每一页最多显示几条数据
	 * @param condition	查询条件的Map集合
	 * @return	条件查询出来的集合
	 */
	public List queryProduct(int page, int max, Map<String, String[]> condition);

	/**
	 * 2、动态条件统计商品的条目数
	 * @param condition	查询条件的Map集合
	 * @return	根据Map集合查询出来的条目数
	 */
	public int findCounToal(Map<String, String[]> condition);

	/**
	 * 3、统计商品表里面的总条目数
	 * @return	商品表里的总的条目数
	 */
	public int counTotal();

	/**
	 * 4、删除商品
	 * @param id	商品的id
	 */
	public void delProduct(int id);
	
	/**
	 * 5、通过id查找商品，用于回显在修改页面
	 * @param id1	商品的id
	 * @return
	 */
	public List findProductById(int id1);
	
	/**
	 * 6、修改商品
	 * @param id 商品的id
	 * @param name 商品名称
	 * @param price 商品价格
	 * @param place 商品产地
	 */
	public void updateProduct(int id, String name, String price, String place);
	
	/**
	 * 7、添加商品
	 * @param name 商品名称
	 * @param prices 商品的价格
	 * @param place	商品的产地
	 * @return	状态值（true或false）
	 */
	public boolean insert(String name, Float prices, String place);
	
	/**
	 * 8、删除选中的商品(批量删除商品)
	 * @param ids	商品的id集合，用于批量删除
	 */
	public void delSelectProduct(String ids[]);
}
