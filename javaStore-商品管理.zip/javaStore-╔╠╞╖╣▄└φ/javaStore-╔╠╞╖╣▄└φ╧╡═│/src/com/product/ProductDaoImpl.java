package com.product;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.model.ProductBean;
import com.tools.MyDB;

public class ProductDaoImpl extends MyDB implements ProductDao {

	/**
	 * 1、分页条件查询方法queryProduct()
	 */
	public List queryProduct(int page, int max, Map<String, String[]> condition) {
		List<ProductBean> list = new ArrayList<ProductBean>();
		try {
			int skip = (page - 1) * max;
			// 获取连接
			getConn();
			String sql = "select * from goods where 1=1";

			StringBuilder sb = new StringBuilder(sql);

			// 遍历map
			Set<String> keySet = condition.keySet();
			// 定义参数的集合
			List<Object> params = new ArrayList<Object>();
			for (String key : keySet) {

				// 排除分页条件参数
				if ("p".equals(key) || "m".equals(key)) {
					continue;
				}
				// 获取value
				String value = condition.get(key)[0];
				// 判断value是否有值
				if (value != null && !"".equals(value)) {
					// 有值
					sb.append(" and " + key + " like " + "'" + value + "'");
					params.add("%" + value + "%");// 条件的值
				}
			}
			// 添加分页查询
			sb.append(" limit " + skip + "," + max);
			// 添加分页查询数值
			params.add(skip);
			params.add(max);
			String sql1 = sb.toString();
//			System.out.println(params);
//			System.out.println(sql1);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql1);
			while (rs.next()) {
				// getLong(1)取第一列的数据
				Long id = rs.getLong(1);
				// getString(2)取第二列的数据
				String name = rs.getString(2);
				// getString(3)取第三列的数据
				String price = rs.getString(3);
				// getString(4)取第三列的数据
				String place = rs.getString(4);
				// 封装成为一个对象
				ProductBean product = new ProductBean();
				product.setId(id);
				product.setName(name);
				product.setPrice(price);
				product.setPlace(place);
				// 把对象塞给list
				list.add(product);
			}
			// 关闭数据库
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList();
		}
		return list;
	}

	/**
	 * 2、动态条件统计商品的条目数findCounToal()
	 */
	public int findCounToal(Map<String, String[]> condition) {
		int total = 0;
		try {
			// 获取连接
			getConn();
			String sql = "select count(*) from goods where 1=1";

			StringBuilder sb = new StringBuilder(sql);

			// 遍历map
			Set<String> keySet = condition.keySet();
			// 定义参数的集合
			List<Object> params = new ArrayList<Object>();
			for (String key : keySet) {

				// 排除分页条件参数
				if ("p".equals(key) || "m".equals(key)) {
					continue;
				}
				// 获取value
				String value = condition.get(key)[0];
				// 判断value是否有值
				if (value != null && !"".equals(value)) {
					// 有值
					sb.append(" and " + key + " like " + "'" + value + "'");
					params.add("%" + value + "%");// 条件的值
					params.toArray();
				}
			}
			String sql1 = sb.toString();
//			System.out.println(params);
//			System.out.println(sql1);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql1);
			while (rs.next()) {
				total = rs.getInt(1);
			}
			// 关闭数据库
			st.close();
			return total;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return total;
	}

	// 测试
//	public static void main(String[] args) {
//		ProductDaoImpl dao=new ProductDaoImpl();
//		Map<String, String[]> map = new HashMap<String, String[]>(); 
//		 int a=dao.findCounToal(map);
//		System.out.println("goods表一共有:"+a+"条数据！");
//	}

	/**
	 * 3、统计商品表里面的总条目数方法counTotal()
	 */
	public int counTotal() {
		int total = 0;
		try {
			// 获取连接
			getConn();
			String sql = "select count(*) from goods";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				total = rs.getInt(1);
			}
			// 关闭数据库
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return total;
	}
	// 测试
//	public static void main(String[] args) {
//		ProductDaoImpl dao=new ProductDaoImpl();
//		int a=dao.counTotal();
//		System.out.println("goods表一共有:"+a+"条数据！");
//	}

	/**
	 * 4、根据商品的id删除商品
	 */
	public void delProduct(int id) {
		try {
			// 获取连接
			getConn();
			String sql = "delete from goods where id=" + id;
			Statement st = conn.createStatement();
			// 执行删除操作要用execute()方法
			boolean rs = st.execute(sql);
			st.close();
			System.out.println(sql);
			System.out.println("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("删除失败！");
		}
	}

	/**
	 * 5、通过id查询是商品
	 */
	public List findProductById(int id1) {
		List<ProductBean> list = new ArrayList<ProductBean>();
		try {
			// 获取连接
			getConn();
			String sql = "select * from goods where id=" + id1;
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				// getLong(1)取第一列的数据
				Long id = rs.getLong(1);
				// getString(2)取第二列的数据
				String name = rs.getString(2);
				// getString(3)取第三列的数据
				String price = rs.getString(3);
				// getString(4)取第三列的数据
				String place = rs.getString(4);
				// 封装成为一个对象
				ProductBean product = new ProductBean();
				product.setId(id);
				product.setName(name);
				product.setPrice(price);
				product.setPlace(place);
				// 把对象塞给list
				list.add(product);
			}
			// 关闭数据库
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList();
		}
		return list;
	}

	/**
	 * 6、修该商品信息
	 */
	public void updateProduct(int id, String name, String price, String place) {
		try {
			// 获取连接
			getConn();
			String sql = "update goods set name=" + "'" + name + "'" + "," + "price=" + "'" + price + "'" + ","
					+ "place=" + "'" + place + "'" + " where id=" + id;
			Statement st = conn.createStatement();
			// 执行修改操作要用execute()方法
			// System.out.println(sql);
			boolean rs = st.execute(sql);
			System.out.println("修改成功!");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("修改失败！");
		}

	}
	// 测试
//	public static void main(String[] args) {
//		ProductDaoImpl dao=new ProductDaoImpl();
//		dao.updateProduct(1, "kl", "1", "美国");
//	}

	/**
	 *  7、添加商品信息
	 */
	public boolean insert(String name, Float price, String place) {
		try {
			// 获取连接
			getConn();
			String sql = "insert into goods (name,price,place)" + "values('" + name + "','" + price + "','" + place
					+ "')";
			Statement st = conn.createStatement();
			// 执行添加、修改、删除操作要用execute()方法
			boolean rs = st.execute(sql);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 8、删除选中的商品
	 */
	public void delSelectProduct(String[] ids) {
		try {
			//获取连接
			getConn();
			//创建dao对象
			ProductDaoImpl dao=new ProductDaoImpl();
			//遍历id集合
			for(int i=0;i<ids.length;i++) {
				//调用删除方法
				dao.delProduct(Integer.parseInt(ids[i]));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
