package com.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.ProductBean;
@WebServlet("/findProductServlet")
public class findProductServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		HttpSession session=req.getSession();
		//获取用户点击的id,用于传递到dao找到对应的商品，然后回显在修改页面
		String id=req.getParameter("id");
		int id1=Integer.parseInt(id);
		
		//创建dao对象
		ProductDaoImpl dao=new ProductDaoImpl();
		List<ProductBean> list=dao.findProductById(id1);
		
		//保存在session中
		session.setAttribute("product", list);
		
		//请求转发到updateProduct.jsp页面
		RequestDispatcher rd = req.getRequestDispatcher("/updateProduct.jsp");
		rd.forward(req, resp);
		
	}

}
