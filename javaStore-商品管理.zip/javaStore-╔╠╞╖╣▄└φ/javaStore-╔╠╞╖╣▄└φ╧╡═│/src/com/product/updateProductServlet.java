package com.product;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

@WebServlet("/com.product/updateProductServlet/update")
public class updateProductServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");

		// 获取数据
		String id = req.getParameter("id");
		int id1 = Integer.parseInt(id);
		String name = req.getParameter("name");
		String price = req.getParameter("price");
		String place = req.getParameter("place");
		// 创建dao对象
		ProductDaoImpl dao = new ProductDaoImpl();
		dao.updateProduct(id1, name, price, place);

		// 重定向到查询所有的servlet
		resp.sendRedirect(req.getContextPath() + "/findProductPageList");
	}

}
