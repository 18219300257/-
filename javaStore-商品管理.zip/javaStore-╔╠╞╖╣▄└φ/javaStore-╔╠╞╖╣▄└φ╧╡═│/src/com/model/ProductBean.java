
package com.model;
/**
 * 商品实体类
 * @author AAA
 *
 */
public class ProductBean {

	private Long id;// 商品id
	private String name;// 商品名字
	private String price;// 商品价格
	private String place;// 商品产地
	private String proimage;// 商品图片
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getProimage() {
		return proimage;
	}

	public void setProimage(String proimage) {
		this.proimage = proimage;
	}

	@Override
	public String toString() {
		return "ProductBean [id=" + id + ", name=" + name + ", price=" + price + ", place=" + place + ", proimage="
				+ proimage + "]";
	}

}
