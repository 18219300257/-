package com.model;

/*
 * 封装管理员的类
 * */
public class AdminBean {
	private int id;// 管理员的id
	private String name;// 管理员姓名
	private String password;// 管理员密码

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "AdminBean [id=" + id + ", name=" + name + ", password=" + password + "]";
	}

}
