// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PageBean.java

package com.model;

import java.util.List;

public class PageBean {

	private int totalCount;// 总的记录数-->可以用数据库的count(*)得到
	private int totalPage;// 总页码数=总记录数 % rows ? 0: 总记录数/rows:（总记录数/rows）+1
	private List list;// 展示集合-->可以通过select(currenPage,rows)得到
	private int currenPage;// 当前的页码数--->可以通前台向后台传递
	private int rows;// 每页要显示的固定记录数

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public int getCurrenPage() {
		return currenPage;
	}

	public void setCurrenPage(int currenPage) {
		this.currenPage = currenPage;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	@Override
	public String toString() {
		return "PageBean [totalCount=" + totalCount + ", totalPage=" + totalPage + ", list=" + list + ", currenPage="
				+ currenPage + ", rows=" + rows + "]";
	}

}
