package com.page;

import java.util.List;
import java.util.Map;

import com.model.PageBean;
import com.product.ProductDao;
import com.product.ProductDaoImpl;

public class Pageservice {
	public PageBean findProductByPage(String _currentPage, String _rows, Map<String,String[]> condition ) {
		// 创建空的PageBean对象
		PageBean page = new PageBean();
		int currentPage = Integer.parseInt(_currentPage);
		int rows = Integer.parseInt(_rows);
		// 判断上一页的条件
		if (currentPage <= 0) {
			currentPage = 1;
		}
		page.setCurrenPage(currentPage);
		page.setRows(rows);
		// 创建Dao对象
		ProductDaoImpl dao = new ProductDaoImpl();
		// 获取条件统计的条目数
		int count = dao.findCounToal(condition);
		page.setTotalCount(count);
		// 获取分页展示的列表List
		List list1 = dao.queryProduct(currentPage, rows, condition);
		page.setList(list1);

		int t;
		if (count % rows == 0)
			t = count / rows;
		else
			t = count / rows + 1;
		page.setTotalPage(t);

		// 判断上一页的条件
		if (currentPage > t)
			currentPage = t;
		page.setCurrenPage(currentPage);
		return page;

	}
}
