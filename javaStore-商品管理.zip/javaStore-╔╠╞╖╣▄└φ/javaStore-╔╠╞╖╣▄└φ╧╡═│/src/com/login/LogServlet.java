package com.login;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.AdminBean;
import com.model.UserBean;

@WebServlet("/com.login/loginServlet/login_1")
public class LogServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 设置编码格式
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		HttpSession session = req.getSession();
		String code = (String) session.getAttribute("trueAnswer");
		session.removeAttribute("trueAnswer");//移除session确保验证码的一次性
		String answer = req.getParameter("code");

		// 判断验证码是否正确
		if (!answer.equals(code)) {
			session.setAttribute("msg", "验证码不正确！");
			req.getRequestDispatcher("/login_1.jsp").forward(req, resp);
			return;
		}
		 //获取选择登陆对象的类型参数
        int type = Integer.parseInt(req.getParameter("gender"));
        //System.out.println(type);
		String user = req.getParameter("username");
		String password = req.getParameter("pswd");
		boolean flag = false;
		//System.out.println(user);
		/*
		 * 用户模块
		 * */
		if(type==2) {
			//System.out.println("用户");
			LogDao dao = new LogDao();
			List<UserBean> list = dao.queryUsers();
			for (int i = 0; i < list.size(); i++) {
				UserBean user1 = list.get(i);
				if (user.equals(user1.getUsername()) && password.equals(user1.getPassword())) {
					// 保存用户已经成工登录的状态
					UserBean bean1 = new UserBean();
					bean1.setUsername(user);
					session.setAttribute("loginedUser", bean1);
//					// 请求转发
//					//System.out.println("转到注册界面");
//					RequestDispatcher rd = req.getRequestDispatcher("/index.jsp");
//					rd.forward(req, resp);
					resp.sendRedirect(req.getContextPath() + "/index.jsp");
					return;//防止出现转发和重定向发生混乱：Cannot forward after response has been committed
				} else {
					flag = true;
				}
			}
			if (flag) {
				session.setAttribute("msg", "用户名或密码错误");
				//把错误信息转发到登录界面
				RequestDispatcher rd = req.getRequestDispatcher("/login_1.jsp");
				rd.forward(req, resp);
//				resp.sendRedirect(req.getContextPath() + "/login_1.jsp");
				
			}
			/*
			 * 管理员模块
			 * */
		}else if (type==1) {
			LogDao dao=new LogDao();
			List<AdminBean> list=dao.queryAdmin();
			for (int i = 0; i < list.size(); i++) {
				AdminBean admin=list.get(i);
				if(user.equals(admin.getName())&&password.equals(admin.getPassword())) {
					//保存管理员登录成功的状态
					AdminBean adm=new AdminBean();
					adm.setName(user);
					session.setAttribute("loginedAdmin", adm);
					// 请求转发
					RequestDispatcher rd = req.getRequestDispatcher("/index_1.jsp");
					rd.forward(req, resp);
					return;
				}else {
					flag = true;
				}
			}
			if (flag) {
				session.setAttribute("msg", "用户名或密码错误");
				//把错误信息转发到登录界面
				RequestDispatcher rd = req.getRequestDispatcher("/login_1.jsp");
				rd.forward(req, resp);
			}
		}


	}

}
