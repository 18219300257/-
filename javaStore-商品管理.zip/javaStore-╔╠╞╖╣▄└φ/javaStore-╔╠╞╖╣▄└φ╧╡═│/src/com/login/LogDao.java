package com.login;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.AdminBean;
import com.model.UserBean;
import com.tools.MyDB;


//查询所有用户
public class LogDao extends MyDB {
	// 定义全查询的方法，用于用户登录是遍历判断
	public List<UserBean> queryUsers() {
		try {
			List<UserBean> list = new ArrayList<UserBean>();
			// 获取连接
			getConn();
			String sql = "select * from tb_users";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				// getLong(1)取第一列的数据
				Long id = rs.getLong(1);
				// getString(2)取第二列的数据
				String name = rs.getString(2);
				// getString(3)取第三列的数据
				String psw = rs.getString(3);
				// 封装成为一个对象
				UserBean user = new UserBean();
				user.setId(id);
				user.setUsername(name);
				user.setPassword(psw);
				// 把对象塞给list
				list.add(user);
			}
			st.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList();
		}

	}
	
	//查询管理员的方法
	public List<AdminBean> queryAdmin(){
		try {
			List<AdminBean> list=new ArrayList<AdminBean>();
			//获取连接
			getConn();
			String sql = "select * from tb_admin";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				// getLong(1)取第一列的数据
				int id = (int) rs.getLong(1);
				// getString(2)取第二列的数据
				String name = rs.getString(2);
				// getString(3)取第三列的数据
				String psw = rs.getString(3);
				// 封装成为一个对象
				AdminBean admin=new AdminBean();
				admin.setId(id);
				admin.setName(name);
				admin.setPassword(psw);
				//把对象塞给List集合
				list.add(admin);
			}
			st.close();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
			return new ArrayList();
		}
		
		
	}
	//测试
//	public static void main(String[] args) {
//		LogDao dao=new LogDao();
//		List<AdminBean> list=dao.queryAdmin();
//		for(int i=0;i<list.size();i++) {
//			AdminBean admin=list.get(i);
//			System.out.println(admin.getId()+" "+admin.getName()+" "+admin.getPassword());
//		}
//	}
//	
	
	//测试
//	public static void main(String[] args) {
//		LogDao dao=new LogDao();
//		List<UserBean> list=dao.queryUsers();
//		for(int i=0;i<list.size();i++) {
//			UserBean user = list.get(i);
//			System.out.println(user.getId() + " " + user.getUsername() + " " + user.getPassword());
//		}
//	}
}
