package com.manageUsers;

import java.util.ArrayList;
import java.util.List;

import com.model.UserBean;
import com.tools.MyDB;

public class UserDaoImpl extends MyDB implements UserDao {

	/**
	 * 分页查询,用户展示用户信息
	 */
	@Override
	public List<UserBean> queryUserList(int pg, int max) {
		List<UserBean> list=new ArrayList<UserBean>();
		try {
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
