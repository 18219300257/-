package com.manageUsers;

import java.util.List;

import com.model.UserBean;



/**
 * 定义用户Dao层的接口
 * @author AAA
 *
 */
public interface UserDao {
	
	/**
	 * 分页查询方法，用于展示用户的信息
	 * @param pg 查看第几页
	 * @param max 每一页显示多少条数据
	 * @return 没有数据返回空列表，而不是返回null
	 */
	public List<UserBean> queryUserList(int pg, int max);
}
