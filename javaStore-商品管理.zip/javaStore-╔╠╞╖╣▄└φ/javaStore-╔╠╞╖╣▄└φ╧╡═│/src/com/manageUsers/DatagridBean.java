package com.manageUsers;

import java.util.List;

/*
 * 封装给easyui-datagrid控件使用在数据
 * */
public class DatagridBean {
	//这两个是数据表格所需的属性名称
		protected int total;//总记录数
		protected List rows;//每一页需要显示的行数
		public int getTotals() {
			return total;
		}
		public void setTotal(int total) {
			this.total = total;
		}
		public List getRows() {
			return rows;
		}
		public void setRows(List rows) {
			this.rows = rows;
		}
}
