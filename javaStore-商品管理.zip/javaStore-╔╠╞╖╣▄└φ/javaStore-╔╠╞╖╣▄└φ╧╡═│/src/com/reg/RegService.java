package com.reg;



/** 封装用户管理的业务功能 **/
public class RegService {
	/** 业务功能，用户注册 **/
	/**
	 * 业务逻辑： 1、用户名不可以为空 2、用户名的长度 3、用户名不可以重复
	 **/
	public static boolean register(String name, String password) {
		// 1、清除空格
		name = name.trim();
		if (name == null || name.isEmpty()) {
			return false;
		}
		if (name.length() > 10) {
			return false;
		}
		RegDao dao=new RegDao();
		return dao.insert(name, password);
	}
}
