package com.reg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/com.reg/RegServlet/reg")
public class RegServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 解决页面乱码问题
		//resp.setHeader("content-type", "text/html;charset=UTF-8");
		String name = req.getParameter("username");
		String password = req.getParameter("pswd");
		HttpSession session = req.getSession();
		RegService reg=new RegService();
		//调用添加的方法
		boolean result=reg.register(name, password);
		if(result==true) {
			//利用会话保存成功信息
			session.setAttribute("msg", "注册成功！");
			//重定向到注册页面
			resp.sendRedirect(req.getContextPath()+"/login_1.jsp");
		}else {
			//利用会话保存成功信息
			session.setAttribute("msg", "注册失败！");
			//重定向到注册页面
			resp.sendRedirect(req.getContextPath()+"/login_1.jsp");
		}
	}

}
