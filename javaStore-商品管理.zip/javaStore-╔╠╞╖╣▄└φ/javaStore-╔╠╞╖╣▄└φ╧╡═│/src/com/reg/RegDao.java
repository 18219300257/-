package com.reg;

import java.sql.Statement;

import com.tools.MyDB;


public class RegDao extends MyDB {
	public boolean insert(String name, String password) {
		try {
			// 获取连接
			getConn();
			Statement st = conn.createStatement();
			String sql = "insert into tb_users (username,password)" + "values('" + name + "','" + password + "')";

			st.execute(sql);
			conn.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
}
